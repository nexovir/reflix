## ⚙️ Requirements

- Python 3.8+
- Go (for installing nuclei)

### Python dependencies:

```bash
pip install -r requirements.txt
